/******************************************************************************
*
*  NSSDC/CDF					Header file for cdfvalidate.
*
*  Version 1.0, 20-Aug-08, Perot System.
*
*  Modification history:
*
*   V1.0  20-Aug-08, M Liu 	Original version.
*
******************************************************************************/

#if !defined(CDFValidateh_INCLUDEd__)
#define CDFValidateh_INCLUDEd__

/******************************************************************************
* Include files.
******************************************************************************/

#include "cdflib.h"
#include "cdflib64.h"
#include "cdftools.h"

/******************************************************************************
* QOP constants.
******************************************************************************/

#define NODEBUGqual		0
#define DEBUGqual		1
#define ABOUTqual		2
#define VALIDATEqual            3
#define NOVALIDATEqual          4

/******************************************************************************
* Global variables.
******************************************************************************/
#if defined(CDFVALIDATE)
Logical useValidate = DEFAULTvalidateValidate;
Logical debug = DEFAULTdebugValidate;
#else
extern Logical useValidate;
extern Logical debug;
#endif

/******************************************************************************
* Function Prototypes.
******************************************************************************/

Logical ValidateCDFs PROTOARGs((int argC, char *argV[]));

/*****************************************************************************/

#endif
