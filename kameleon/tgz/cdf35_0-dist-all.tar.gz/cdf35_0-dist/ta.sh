#! /bin/sh

str='/home/liu/cdf35_0-dist/bin/definitions.B'
echo "${str: -1}"

str='/Users/btharris/opt/cdf3.5.0.2_64bit/bin/definitions.B'
echo "${str: -1}"

